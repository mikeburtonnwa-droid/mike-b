# Synthetic request routing — discovery to design — current state

Derived from revision 40; as of 2026-09-09.

No local simulation is activated. No infrastructure deployment is recorded here.

```mermaid
flowchart TD
  P01(["P01: Receive request in intake queue / Frontline intake"])
  P02["P02: Copy fields into email to operations / Frontline intake"]
  P03{"P03: Operations triages accepted request urgency / Operations"}
  P04{"P04: Finance selects latest credit decision for standard request / Finance"}
  P05(["P05: Record fulfillment routing disposition / Fulfillment"])
  P06(["P06: Record finance-review routing disposition / Finance"])
  P07(["P07: Record service-desk manual-review disposition / Service desk"])
  P01 -->|"handoff: request received"| P02
  P02 -->|"handoff: operations takes the emailed request"| P03
  P03 -->|"exception: urgent handling"| P07
  P03 -->|"handoff: standard request"| P04
  P04 -->|"handoff: latest decision approved"| P05
  P04 -->|"exception: latest decision denied"| P06
  P04 -->|"exception: credit decision missing"| P06
```

| ID / variant | Actor / system / boundary | Inputs → outputs | Evidence / prerequisites |
| --- | --- | --- | --- |
| P01 / reported intake handoff | Frontline intake / intake queue; product unknown / Frontline intake | request → request available to frontline intake | C01, S01 |
| P02 / reported intake handoff | Frontline intake / email; product unknown / Frontline intake | tenant, request ID, customer ID, urgency → email containing tenant, request ID, customer ID and urgency | C02, C05, S01 |
| P03 / reported intake handoff | Operations / Operations triage; product unspecified / Internal operations | tenant, request ID, customer ID, urgency → urgency classification, routing work item | C09, C10, S03 |
| P04 / normal requests | Finance / Finance approval export / review / Internal finance | tenant, request ID, approval events → latest approval or explicit absence | C11, S03, S04 |
| P05 / normal requests | Fulfillment / Separate internal fulfillment system / Internal fulfillment | tenant, request ID, approved latest decision → fulfillment routing disposition | C10, C11, S03, S10 |
| P06 / normal requests | Finance / Finance review / Internal finance | tenant, request ID, denied or absent latest decision → finance-review routing disposition | C11, S03, S04 |
| P07 / urgent requests | Service desk / Service desk review / Support | tenant, request ID, customer ID, urgent review request → service-desk routing disposition | C09, C10, S03, S10 |

## Gaps and coverage

- CV08: coverage gap: Operations identifies the service desk and bounded route; obtain receiving-owner acknowledgement and payload confirmation before claiming live coverage. Fixed-fixture design can proceed.
- CV09: coverage gap: Operations names the fulfillment route and separate system; obtain receiving-owner acknowledgement and endpoint contract before live design is finalized. Fixed-fixture design can proceed.
- coverage: stakeholder Fulfillment lacks matching current-step evidence
- coverage: stakeholder Service desk lacks matching current-step evidence

## Handoffs and paths

| From → to | Kind / condition | Payload | Receiver |
| --- | --- | --- | --- |
| P01 → P02 | handoff / request received | request details from the intake queue | Frontline intake |
| P02 → P03 | handoff / operations takes the emailed request | email containing tenant, request ID, customer ID and urgency | Operations |
| P03 → P07 | exception / urgent handling | tenant, request ID, customer ID, urgency and service-desk review request | Service desk |
| P03 → P04 | handoff / standard request | tenant and request ID for latest credit decision | Finance |
| P04 → P05 | handoff / latest decision approved | tenant, request ID, selected decision_seq and fulfillment disposition | Fulfillment |
| P04 → P06 | exception / latest decision denied | tenant, request ID, selected denial and finance-review disposition | Finance |
| P04 → P06 | exception / credit decision missing | tenant, request ID, missing-decision reason and finance-review disposition | Finance |

## Declared coverage

Covered means an attributed account exists for the declared step; it does not establish exhaustive or independently verified coverage.

| Dimension / value | Status | Steps | Source locators / gap |
| --- | --- | --- | --- |
| stakeholder / Frontline intake | covered | P01, P02 | S01 line 6, sentence 1; S01 line 6, sentence 2; S01 line 6, sentence 5  |
| stakeholder / Operations | covered | P03 | S03 line 6  |
| variant / reported intake handoff | covered | P01, P02, P03 | S01 line 6, sentence 1; S01 line 6, sentence 2; S01 line 6, sentence 5  |
| variant / normal requests | covered | P04, P05, P06 | S03 line 6; S04 line 6; S10 line 6  |
| variant / urgent requests | covered | P07 | S03 line 6; S10 line 6  |
| exception / urgent handling | covered | P03 | S03 line 6, sentences 3-4  |
| stakeholder / Finance | covered | P04, P06 | S04 line 6  |
| stakeholder / Service desk | gap | P07 | S03 line 6 Operations identifies the service desk and bounded route; obtain receiving-owner acknowledgement and payload confirmation before claiming live coverage. Fixed-fixture design can proceed. |
| stakeholder / Fulfillment | gap | P05 | S03 line 6 Operations names the fulfillment route and separate system; obtain receiving-owner acknowledgement and endpoint contract before live design is finalized. Fixed-fixture design can proceed. |
| exception / latest decision denied | covered | P04 | S03 line 6; S04 line 6  |
| exception / credit decision missing | covered | P04 | S04 line 6  |

## Knowledge

| Claim | Status / freshness | Sources and locators |
| --- | --- | --- |
| C01: The simulated frontline interviewee receives requests in the intake queue. | reported / unknown | S01 line 6, sentence 1 |
| C02: The interviewee copies tenant, request ID, customer ID and urgency into an email to operations. | reported / unknown | S01 line 6, sentence 2 |
| C03: A normal request goes through a credit check and then fulfillment, according to the frontline interviewee. | reported / unknown | S01 line 6, sentence 3 |
| C04: The interviewee has seen urgent requests handled differently but does not know who owns those exceptions. | reported / unknown | S01 line 6, sentence 4 |
| C05: The interviewee&#x27;s part ends when operations takes the request. | reported / unknown | S01 line 6, sentence 5 |
| C06: The interviewee cannot speak for the whole process or name the overall process owner. | reported / unknown | S01 line 6, sentence 6 |
| C07: The interviewee reports that time is lost chasing status. | reported / unknown | S01 line 6, sentence 7 |
| C09: Urgent requests go from Operations to the service desk for manual review and a routing disposition; Finance does not own or assess them. | reported / unknown | S03 line 6, sentences 2-7; S04 line 6, sentence 5 |
| C10: Operations owns the bounded workflow from intake acceptance to recorded routing disposition, before shipment or financial authorization. | reported / unknown | S03 line 6, sentences 1 and 7; S10 line 6, sentences 1-2 |
| C11: For each standard request use the greatest decision_seq within tenant and request_id; approved routes fulfillment, denied or missing routes finance-review. | reported / unknown | S04 line 6, sentences 1-4; S03 line 6, sentences 5-6 |
| C12: Request identity is tenant/request_id; customer identity is tenant/customer_id; approval and handoff events add decision_seq and event_seq respectively, and only each latest event enriches a request. | reported / unknown | S05 line 6; S11 lines 6-13 |
| C13: Reporting describes customer_id-only joins and joining all approval and handoff events as producing duplicate requests and cross-tenant customer enrichment. | reported / unknown | S06 line 6 |
| C14: Every enrichment join and output must retain tenant and must not include another tenant&#x27;s customer. | reported / unknown | S07 line 6, sentences 1-2 |
| C15: Inputs model a daily export; version capture is required and dates do not establish continuing accuracy; there is no deployed service. | reported / unknown | S08 line 6 |
| C16: Loss of approval input should be rehearsed with a local fault, diagnosis, authorized fixture restoration and the same acceptance criterion; unsuccessful recovery must keep an incident open. | reported / unknown | S09 line 6 |
| C17: Acceptance requires exactly one output per supplied tenant/request key, tenant-isolated customer enrichment, and routes north/R1 fulfillment, north/R2 finance-review, north/R3 service-desk and south/R4 fulfillment. | reported / unknown | S10 line 6, sentences 3-6 |
| C18: Customers seek a quick disposition, not automatic shipment. | reported / unknown | S02 line 6, sentence 3 |
| C19: The supplied exercise permits local synthetic work and excludes production credentials, live customer data, network database access, shipment and financial mutation; actual authorization remains the user&#x27;s task instruction. | reported / unknown | S07 line 6, sentences 3-5 |
| C20: Urgent requests go from Operations to the service desk for manual review and a routing disposition; Finance does not own or assess them. | reported / unknown | S03 line 6, sentences 2-7; S04 line 6, sentence 5; S10 line 6, sentence 4 |
| C21: Q02 returns four rows for four supplied tenant/request keys with zero cross-tenant customer rows and all four sponsor-expected routing dispositions. | verified / current | S13 rows[0:4] and query_fingerprint; S15 expected, observed, matches_fixed_fixture_expectations |
| C22: Q01 returns 13 rows for four distinct tenant/request keys, including six rows where customer tenant differs from request tenant. | verified / current | S12 rows and query_fingerprint; S15 Q01 |
| C23: Supplied tables contain 4 requests, 3 customers, 4 approval events and 5 handoff events; checked keys and required fields have zero duplicates/nulls; checked customer/approval/handoff references have zero orphans. One request lacks approval, but zero standard requests lack approval. | verified / current | S14 rows[0:9] |
| C24: Q04 returns four rows for four supplied tenant/request keys with zero cross-tenant customer rows and all four sponsor-expected routing dispositions. | verified / current | S17 rows[0:4] and query_fingerprint; S19 expected, observed, matches_fixed_fixture_expectations |
| C25: Supplied tables contain 4 requests, 3 customers, 4 approval events and 5 handoff events; checked keys and required fields have zero duplicates/nulls; checked customer/approval/handoff references have zero orphans. One request lacks approval, but zero standard requests lack approval. | verified / current | S18 rows[0:9] |

## Resume

Current task: Resume complete: reconcile supplied stakeholder notes and schema; hand off a bounded fixed-fixture routing design.

Stage: design

Next action: **Review deliverables/discovery-to-design.md and H01. Next session should specify a fixture-only input/output/failure contract, create proposed map nodes with current baselines and a deterministic component design, and define separate tests for REQ01-REQ03 plus missing-standard-decision and unavailable-feed cases before build. Ask Operations for receiver acknowledgement details only within then-existing authorization; no contact has been made.**

Completed:

- Recovered revision 4 audit, checkpoint, brief, current context, first-interview handoff and captured S01 without earlier chat.
- Captured S02-S11 original stakeholder notes and schema, retaining scenario/capture dates and explicit synthetic scope; S03 states policy effective 2026-09-01.
- Updated authoritative brief to Operations-owned intake acceptance through recorded routing disposition; resolved I01.
- Reconciled Sales&#x27; unchecked finance-owns-urgent account with Operations, Finance and sponsor; C08 superseded by C20; current time-scoped policy C09 retained. Archived obsolete first-session method note N01.
- Extended current map P03-P07 and coverage CV02/CV04-CV11; preserved receiving-owner gaps and open operational questions.
- Recorded D01-D04 grains, keys and daily-export limitations. Executed Q01-Q03 in local in-memory SQLite with pre-run query fingerprints; captured S12-S16 and bound all results. Archived semantically bad Q01 while retaining its result.
- Observed Q01 13 rows / 4 request keys / 6 cross-tenant rows. Q02 returned 4 rows / 4 keys / 0 cross-tenant rows and expected routes. Q03 checked source grain, required nulls, orphans and missing approvals. C21-C23 verified only for these fixed fixture observations on 2026-09-09.
- Saved separate REQ01-REQ03, deterministic routing recommendation DEC01, eight explicitly deferred architecture concerns AC01-AC08 and discovery-to-design handoff H01.
- Current-process check failed only on two receiver coverage gaps and corresponding coverage findings. Architecture check failed because implementing components and all eight deferred concerns remain. Release check failed; no evaluation, incident, release, activation or deployment was created.
- Final source-pointer review corrected three S03 sentence locators. Executed and bound fresh Q04/Q05 versions with unchanged SQL but updated dependency fingerprints; preserved and archived Q02/Q03. Current results S17-S20, C24/C25 match prior fixed-fixture observations. Migrated DEC01/H01, concerns and I07 to current evidence.

Unresolved:

- I02/CV08/CV09: Service-desk and fulfillment receiver confirmation, tools, payload acknowledgements and timing remain unobserved. They do not prevent fixed-fixture design, but block complete operational coverage.
- I03/I07: Missing standard credit has policy support but no supplied fixture case; invalid input, missing customer, unavailable approval feed, duplicate/uncertain operational writes and recovery need design and separate cases.
- I04: Status-chasing frequency, elapsed time, target benefit and export-age SLA are unknown.
- I05: Actual historical failed report SQL/output was not supplied; Q01 is clearly a reconstruction.
- I06/AC01-AC08: Runtime component, state/retention, input refresh checks, access controls, policy retrieval, monitoring, accountable operator and fresh acceptance/recovery evidence remain future work.
- All stakeholder policy/practice claims remain reported; synthetic fixed-result claims C22/C24/C25 have same-day review dates and must not be treated as verified live process. No earlier chat or deployment authorization is assumed.

Relevant records: H01, REQ01, REQ02, REQ03, DEC01, C09, C10, C11, C20, C22, N02, N03, D01, D02, D03, D04, Q01, S03, S04, S10, S11, S12, S13, S14, S15, S16, P01, P02, P03, P04, P05, P06, P07, I02, I03, I04, I05, I06, I07, CV08, CV09, AC01, AC02, AC03, AC04, AC05, AC06, AC07, AC08, Q04, Q05, C24, C25, S17, S18, S19, S20

Structural checks cannot prove that every stakeholder or real exception has been discovered.

