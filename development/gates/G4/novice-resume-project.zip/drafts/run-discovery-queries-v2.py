import json, pathlib, sqlite3, subprocess, sys
from datetime import datetime, timezone
project=pathlib.Path('work/novice-order-project')
cli=['python3','outputs/agent-architect/scripts/aa.py','--project',str(project)]
def call(args):
 p=subprocess.run(cli+args,capture_output=True,text=True)
 print(json.dumps({'nested_command':cli+args,'stdout':p.stdout,'stderr':p.stderr,'exit_code':p.returncode}))
 if p.returncode: raise RuntimeError('CLI read failed')
 return json.loads(p.stdout)
state=call(['show'])
original=(project/state['records']['S11']['blob']).read_text()
expected={'request_keys':[['north','R1'],['north','R2'],['north','R3'],['south','R4']],'output_rows':4,'cross_tenant_rows':0,'routes':{'north/R1':'fulfillment','north/R2':'finance-review','north/R3':'service-desk','south/R4':'fulfillment'}}
print(json.dumps({'expected_defined_before_execution':expected,'source':'S10 line 6; S11 lines 10-13','scope':'local discovery observation, not architecture evaluation'}))
outputs={}
for qid in ['Q04','Q05']:
 fingerprint=call(['query-fingerprint',qid])
 q=state['records'][qid]
 conn=sqlite3.connect(':memory:')
 conn.row_factory=sqlite3.Row
 conn.executescript(original)
 conn.execute('PRAGMA query_only=ON')
 run_at=datetime.now(timezone.utc)
 rows=[dict(r) for r in conn.execute(q['sql'],q['parameters'])]
 conn.close()
 result={'environment':'synthetic-training','run_on':run_at.date().isoformat(),'command':'python3 work/novice-order-project/drafts/run-discovery-queries-v2.py; '+qid+' SQL from revision '+str(state['revision'])+'; captured S11 in-memory fixture; PRAGMA query_only=ON','exit_code':0,'query_fingerprint':fingerprint,'rows':rows}
 result_path=project/'drafts'/(qid+'-result.json')
 result_path.write_text(json.dumps(result,indent=2)+'\n')
 outputs[qid]=result
 print(json.dumps({'query':qid,'sql':q['sql'],'result':result,'file':str(result_path)},indent=2))
summary={}
for qid in ['Q04']:
 rows=outputs[qid]['rows']
 summary[qid]={'output_rows':len(rows),'distinct_request_keys':len({(r['tenant'],r['request_id']) for r in rows}),'cross_tenant_rows':sum(r['customer_tenant'] is not None and r['customer_tenant']!=r['tenant'] for r in rows)}
good=outputs['Q04']['rows']
observed={'request_keys':[list(k) for k in sorted({(r['tenant'],r['request_id']) for r in good})],'output_rows':len(good),'cross_tenant_rows':summary['Q04']['cross_tenant_rows'],'routes':{r['tenant']+'/'+r['request_id']:r['routing_disposition'] for r in good}}
summary.update({'expected':expected,'observed':observed,'matches_fixed_fixture_expectations':observed==expected,'environment':'synthetic-training','sqlite_version':sqlite3.sqlite_version,'limitations':['Not an architecture evaluation; no implementing component captured.','No standard request lacks a credit decision in supplied rows.','Missing customer, malformed inputs, acknowledgement and approval-feed outage not exercised.','No timestamps available to validate live export freshness.','Q01 reconstructs described bad joins; original historical report was not supplied.']})
(project/'drafts'/'discovery-observation-summary-v2.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
